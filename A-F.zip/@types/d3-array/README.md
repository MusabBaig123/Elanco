# Installation
> `npm install --save @types/d3-array`

# Summary
This package contains type definitions for d3-array (https://github.com/d3/d3-array).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/d3-array.

### Additional Details
 * Last updated: Fri, 12 Sep 2025 20:02:35 GMT
 * Dependencies: none

# Credits
These definitions were written by [Alex Ford](https://github.com/gustavderdrache), [Boris Yankov](https://github.com/borisyankov), [Tom Wanzek](https://github.com/tomwanzek), [denisname](https://github.com/denisname), [Hugues Stefanski](https://github.com/ledragon), [Nathan Bierema](https://github.com/Methuselah96), and [Fil](https://github.com/Fil).
