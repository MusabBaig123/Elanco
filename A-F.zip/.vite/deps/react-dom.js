import {
  require_react_dom
} from "./chunk-QHCQHC5C.js";
import "./chunk-PWLNVQY7.js";
export default require_react_dom();
