import {
  require_react
} from "./chunk-PWLNVQY7.js";
export default require_react();
