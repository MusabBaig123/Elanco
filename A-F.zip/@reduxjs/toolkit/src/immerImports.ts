export {
  current,
  isDraft,
  produce as createNextState,
  isDraftable,
  setUseStrictIteration,
} from 'immer'
