export {
  current,
  isDraft,
  applyPatches,
  original,
  isDraftable,
  produceWithPatches,
  enablePatches,
} from 'immer'
