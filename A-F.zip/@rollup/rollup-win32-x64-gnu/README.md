# `@rollup/rollup-win32-x64-gnu`

This is the **x86_64-pc-windows-gnu** binary for `rollup`
