/**
 * @fileOverview Cross
 */

export var Cell = _props => null;
Cell.displayName = 'Cell';