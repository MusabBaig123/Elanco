import { createContext } from 'react';
export var BrushUpdateDispatchContext = /*#__PURE__*/createContext(() => {});